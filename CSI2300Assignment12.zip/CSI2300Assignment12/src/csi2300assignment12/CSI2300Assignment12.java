/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package csi2300assignment12;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Pattern;

/**
 *
 * @author sstan
 */
public class CSI2300Assignment12 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // validate if password satisfies requirements
        /*
            1. The password's length is between 8 and 16 (inclusive)
            2. The password must be a combination of at least three out of the following four categories:

                (1) lower case letters, i.e., a-z
                (2) upper case letters, i.e., A-Z
                (3) numbers, i.e., 0-9
                (4) the following special symbols: ~!@#$%^&*()-=+_
        */
        
        Scanner pass = new Scanner(System.in);
        System.out.println("Enter Password: ");
        String enterPassword = pass.nextLine(); 
        System.out.println("Enter Password again to confirm: ");
        String passwordConfirmation = pass.nextLine(); 
        
        System.out.println("The password entered is: " + enterPassword); 
        
        // password and password confirmation do not match
        while (!errorList.isEmpty()) {
            System.out.println("Invalid Password, please enter a valid password ");
            System.out.println("Password must contain: " 
                    + "a lowercase letter (a-z) and a upercase letter(A-Z), " 
                    + "a number (0-9) and a special char. (~!@#$%^&*()-=+_)"); 
            String enterPassword1 = pass.nextLine();
            System.out.print("Enter valid password: ");                                     
            }// end of while
    }
    
    public static List<String> Valid(String enterPassword, String confirmation) {
         List<String> errorList;
        errorList = new ArrayList<>();
        Object passwordConfirmation = null;
       
        
        Pattern specailCharPatten = Pattern.compile("[^a-z0-9 ]", Pattern.CASE_INSENSITIVE);
        Pattern UpperCasePatten = Pattern.compile("[A-Z ]");
        Pattern lowerCasePatten = Pattern.compile("[a-z ]");
        Pattern digitCasePatten = Pattern.compile("[0-9 ]");
        
        if (!enterPassword.equals(passwordConfirmation)) {
        errorList.add("password and confirm password does not match");
    }
    if (passwordhere.length() <= 8) {
        errorList.add("Password lenght must have alleast 8 character !!");
    }
    if (!specailCharPatten.matcher(enterPassword).find()) {
        errorList.add("Password must have atleast one specail character !!");
    }
    if (!UpperCasePatten.matcher(enterPassword).find()) {
        errorList.add("Password must have atleast one uppercase character !!");
    }
    if (!lowerCasePatten.matcher(enterPassword).find()) {
        errorList.add("Password must have atleast one lowercase character !!");
    }
    if (!digitCasePatten.matcher(enterPassword).find()) {
        errorList.add("Password must have atleast one digit character !!");
    }
    return errorList;      
        
    }
}

    

   
